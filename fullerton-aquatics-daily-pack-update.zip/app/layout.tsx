import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Fullerton Aquatics TCG', description: 'Collect, open packs, and trade Fullerton Aquatics cards.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
