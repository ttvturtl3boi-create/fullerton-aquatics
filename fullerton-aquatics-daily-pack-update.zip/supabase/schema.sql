-- Fullerton Aquatics TCG: run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  is_admin boolean not null default false,
  starter_claimed_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.cards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  rarity text not null check (rarity in ('Basic','Mythical','Ultra Bazinga')),
  image_url text not null,
  description text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by uuid references public.profiles(id)
);
create table if not exists public.owned_cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  card_id uuid not null references public.cards(id),
  acquired_at timestamptz not null default now(),
  source text not null default 'pack' check (source in ('starter','pack','trade','admin'))
);
create index if not exists owned_cards_user_idx on public.owned_cards(user_id);
create index if not exists owned_cards_card_idx on public.owned_cards(card_id);
create table if not exists public.pack_openings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  week_key date not null,
  opened_at timestamptz not null default now()
  -- Multiple openings are allowed; the 48-hour cooldown is enforced by opened_at.
);
create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  proposer_id uuid not null references public.profiles(id),
  recipient_id uuid not null references public.profiles(id),
  status text not null default 'pending' check(status in ('pending','accepted','declined','cancelled')),
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  check(proposer_id <> recipient_id)
);
create table if not exists public.trade_items (
  id uuid primary key default gen_random_uuid(),
  trade_id uuid not null references public.trades(id) on delete cascade,
  side text not null check(side in ('offered','requested')),
  owner_id uuid not null references public.profiles(id),
  owned_card_id uuid not null references public.owned_cards(id),
  unique(trade_id, owned_card_id)
);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id, username) values(new.id, coalesce(split_part(new.email,'@',1),'swimmer')) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Retained for compatibility with older dashboards; pack eligibility is now per-player 48 hours.
create or replace function public.current_pack_week() returns date language sql stable as $$
 select (now() at time zone 'America/Los_Angeles')::date;
$$;

-- Rarity first; then bias toward less-owned cards and away from cards pulled recently.
create or replace function public.pick_pack_card(p_user uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare chosen_rarity text; chosen_card uuid; roll numeric;
begin
 roll := random()*100;
 chosen_rarity := case when roll < 3 then 'Ultra Bazinga' when roll < 25 then 'Mythical' else 'Basic' end;
 select c.id into chosen_card
 from public.cards c
 where c.active and c.rarity=chosen_rarity
 order by (-ln(greatest(random(),0.000001))) /
   (1.0 / (1 + (select count(*) from public.owned_cards oc where oc.user_id=p_user and oc.card_id=c.id)*0.55)
    * case when exists(select 1 from public.owned_cards recent where recent.user_id=p_user and recent.card_id=c.id and recent.acquired_at > now()-interval '14 days') then 0.38 else 1.0 end)
 limit 1;
 if chosen_card is null then
   select c.id into chosen_card from public.cards c where c.active
   order by random() limit 1;
 end if;
 return chosen_card;
end; $$;

create or replace function public.claim_starter_cards() returns table(owned_id uuid, card_id uuid, name text, rarity text, image_url text)
language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); cid uuid; i int;
begin
 if uid is null then raise exception 'Sign in first.'; end if;
 perform 1 from public.profiles where id=uid for update;
 if exists(select 1 from public.profiles where id=uid and starter_claimed_at is not null) then raise exception 'Starter cards have already been claimed.'; end if;
 if not exists(select 1 from public.cards where active) then raise exception 'No active cards are available yet.'; end if;
 for i in 1..3 loop
   cid := public.pick_pack_card(uid);
   insert into public.owned_cards(user_id,card_id,source) values(uid,cid,'starter') returning id into owned_id;
   select c.id,c.name,c.rarity,c.image_url into card_id,name,rarity,image_url from public.cards c where c.id=cid;
   return next;
 end loop;
 update public.profiles set starter_claimed_at=now() where id=uid;
end; $$;

create or replace function public.open_weekly_pack() returns table(owned_id uuid, card_id uuid, name text, rarity text, image_url text)
language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); cid uuid; i int; last_opened timestamptz; opened timestamptz := now();
begin
 if uid is null then raise exception 'Sign in first.'; end if;
 -- Serialize pack claims for this player so two simultaneous requests cannot bypass the cooldown.
 perform 1 from public.profiles where id=uid for update;
 if not found then raise exception 'Player profile not found.'; end if;
 select max(po.opened_at) into last_opened from public.pack_openings po where po.user_id=uid;
 if last_opened is not null and last_opened + interval '48 hours' > opened then
   raise exception 'Your next free pack is available at %.', to_char(last_opened + interval '48 hours', 'Mon DD, YYYY HH12:MI AM');
 end if;
 if not exists(select 1 from public.cards where active) then raise exception 'No active cards are available yet.'; end if;
 insert into public.pack_openings(user_id,week_key,opened_at)
 values(uid,(opened at time zone 'America/Los_Angeles')::date,opened);
 for i in 1..3 loop
   cid := public.pick_pack_card(uid);
   insert into public.owned_cards(user_id,card_id,source) values(uid,cid,'pack') returning id into owned_id;
   select c.id,c.name,c.rarity,c.image_url into card_id,name,rarity,image_url from public.cards c where c.id=cid;
   return next;
 end loop;
end; $$;

create or replace function public.accept_trade(p_trade uuid) returns void language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); t public.trades%rowtype; item record;
begin
 if uid is null then raise exception 'Sign in first.'; end if;
 select * into t from public.trades where id=p_trade for update;
 if not found or t.status <> 'pending' then raise exception 'Trade is no longer available.'; end if;
 if uid <> t.recipient_id then raise exception 'Only the recipient can accept this trade.'; end if;
 if not exists(select 1 from public.trade_items where trade_id=p_trade and side='offered') or not exists(select 1 from public.trade_items where trade_id=p_trade and side='requested') then raise exception 'Both sides of the trade need at least one card.'; end if;
 for item in select ti.*, oc.user_id current_owner from public.trade_items ti join public.owned_cards oc on oc.id=ti.owned_card_id where ti.trade_id=p_trade for update of oc loop
   if item.current_owner <> item.owner_id then raise exception 'A card in this trade is no longer owned by the expected player.'; end if;
   if item.side='offered' and item.owner_id <> t.proposer_id then raise exception 'Invalid offered card.'; end if;
   if item.side='requested' and item.owner_id <> t.recipient_id then raise exception 'Invalid requested card.'; end if;
 end loop;
 update public.owned_cards oc set user_id=case when ti.side='offered' then t.recipient_id else t.proposer_id end, source='trade', acquired_at=now()
 from public.trade_items ti where ti.trade_id=p_trade and oc.id=ti.owned_card_id;
 update public.trades set status='accepted',completed_at=now() where id=p_trade;
end; $$;


-- Admin management: admins can grant/revoke other admins or transfer their own control.
create or replace function public.set_player_admin(p_target uuid, p_is_admin boolean)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); admin_count int;
begin
 if uid is null or not exists(select 1 from public.profiles where id=uid and is_admin) then raise exception 'Administrator access required.'; end if;
 if not exists(select 1 from public.profiles where id=p_target) then raise exception 'Player account not found.'; end if;
 if p_target=uid and not p_is_admin then
   select count(*) into admin_count from public.profiles where is_admin;
   if admin_count <= 1 then raise exception 'The last administrator cannot remove their own access.'; end if;
 end if;
 update public.profiles set is_admin=p_is_admin where id=p_target;
end; $$;

create or replace function public.transfer_admin_control(p_target uuid)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid();
begin
 if uid is null or not exists(select 1 from public.profiles where id=uid and is_admin) then raise exception 'Administrator access required.'; end if;
 if p_target=uid then raise exception 'Choose another player to receive administrator control.'; end if;
 perform 1 from public.profiles where id in (uid,p_target) for update;
 if not exists(select 1 from public.profiles where id=p_target) then raise exception 'Player account not found.'; end if;
 update public.profiles set is_admin=true where id=p_target;
 update public.profiles set is_admin=false where id=uid;
end; $$;

alter table public.profiles enable row level security;
alter table public.cards enable row level security;
alter table public.owned_cards enable row level security;
alter table public.pack_openings enable row level security;
alter table public.trades enable row level security;
alter table public.trade_items enable row level security;

create policy "profiles readable to signed in users" on public.profiles for select to authenticated using(true);
create policy "active cards visible" on public.cards for select to authenticated using(active or exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "admins insert cards" on public.cards for insert to authenticated with check(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "admins update cards" on public.cards for update to authenticated using(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin)) with check(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "admins delete cards" on public.cards for delete to authenticated using(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "players see only their own card copies" on public.owned_cards for select to authenticated using(user_id=auth.uid());
create policy "no direct owned card inserts" on public.owned_cards for insert to authenticated with check(false);
create policy "no direct owned card updates" on public.owned_cards for update to authenticated using(false);
create policy "no direct owned card deletes" on public.owned_cards for delete to authenticated using(false);
create policy "view own pack openings" on public.pack_openings for select to authenticated using(user_id=auth.uid());
create policy "trade participants view trades" on public.trades for select to authenticated using(proposer_id=auth.uid() or recipient_id=auth.uid());
create policy "users create trades they propose" on public.trades for insert to authenticated with check(proposer_id=auth.uid() and status='pending');
create policy "participants view trade items" on public.trade_items for select to authenticated using(exists(select 1 from public.trades t where t.id=trade_id and (t.proposer_id=auth.uid() or t.recipient_id=auth.uid())));
create policy "proposer adds trade items" on public.trade_items for insert to authenticated with check(
 exists(select 1 from public.trades t where t.id=trade_id and t.proposer_id=auth.uid()) and
 ((side='offered' and owner_id=auth.uid() and exists(select 1 from public.owned_cards oc where oc.id=owned_card_id and oc.user_id=auth.uid())) or
  (side='requested' and exists(select 1 from public.trades t join public.owned_cards oc on oc.user_id=t.recipient_id where t.id=trade_id and oc.id=owned_card_id and owner_id=t.recipient_id)))
);

grant execute on function public.claim_starter_cards() to authenticated;
grant execute on function public.open_weekly_pack() to authenticated;
grant execute on function public.accept_trade(uuid) to authenticated;
grant execute on function public.set_player_admin(uuid,boolean) to authenticated;
grant execute on function public.transfer_admin_control(uuid) to authenticated;
grant execute on function public.current_pack_week() to authenticated;
revoke all on function public.pick_pack_card(uuid) from public, authenticated;

-- Create a public image bucket. Uploads are restricted to approved admins by policy.
insert into storage.buckets(id,name,public) values('card-images','card-images',true) on conflict(id) do nothing;
create policy "public can view card images" on storage.objects for select using(bucket_id='card-images');
create policy "admins upload card images" on storage.objects for insert to authenticated with check(bucket_id='card-images' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "admins update card images" on storage.objects for update to authenticated using(bucket_id='card-images' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "admins delete card images" on storage.objects for delete to authenticated using(bucket_id='card-images' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
