-- Run this migration if you already installed the earlier schema.sql.
alter table public.cards add column if not exists description text;

create or replace function public.set_player_admin(p_target uuid, p_is_admin boolean)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); admin_count int;
begin
 if uid is null or not exists(select 1 from public.profiles where id=uid and is_admin) then raise exception 'Administrator access required.'; end if;
 if not exists(select 1 from public.profiles where id=p_target) then raise exception 'Player account not found.'; end if;
 if p_target=uid and not p_is_admin then select count(*) into admin_count from public.profiles where is_admin; if admin_count <= 1 then raise exception 'The last administrator cannot remove their own access.'; end if; end if;
 update public.profiles set is_admin=p_is_admin where id=p_target;
end; $$;

create or replace function public.transfer_admin_control(p_target uuid)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid();
begin
 if uid is null or not exists(select 1 from public.profiles where id=uid and is_admin) then raise exception 'Administrator access required.'; end if;
 if p_target=uid then raise exception 'Choose another player to receive administrator control.'; end if;
 perform 1 from public.profiles where id in (uid,p_target) for update;
 if not exists(select 1 from public.profiles where id=p_target) then raise exception 'Player account not found.'; end if;
 update public.profiles set is_admin=true where id=p_target;
 update public.profiles set is_admin=false where id=uid;
end; $$;

grant execute on function public.set_player_admin(uuid,boolean) to authenticated;
grant execute on function public.transfer_admin_control(uuid) to authenticated;
create policy "admins delete card images" on storage.objects for delete to authenticated using(bucket_id='card-images' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
