-- Fullerton Aquatics: change free packs from weekly to every 48 hours.
-- Run this ONCE in Supabase SQL Editor. It preserves all existing card copies and opening history.

-- The old unique(user_id, week_key) rule prevented more than one opening per calendar week.
-- Remove it; the function below enforces a rolling 48-hour cooldown instead.
alter table public.pack_openings
  drop constraint if exists pack_openings_user_id_week_key_key;

create or replace function public.open_weekly_pack()
returns table(owned_id uuid, card_id uuid, name text, rarity text, image_url text)
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  cid uuid;
  i int;
  last_opened timestamptz;
  opened timestamptz := now();
begin
  if uid is null then raise exception 'Sign in first.'; end if;

  -- Lock this player's profile to prevent simultaneous requests bypassing the cooldown.
  perform 1 from public.profiles where id = uid for update;
  if not found then raise exception 'Player profile not found.'; end if;

  select max(po.opened_at) into last_opened
  from public.pack_openings po
  where po.user_id = uid;

  if last_opened is not null and last_opened + interval '48 hours' > opened then
    raise exception 'Your next free pack is not available yet.';
  end if;

  if not exists(select 1 from public.cards where active) then
    raise exception 'No active cards are available yet.';
  end if;

  insert into public.pack_openings(user_id, week_key, opened_at)
  values(uid, (opened at time zone 'America/Los_Angeles')::date, opened);

  for i in 1..3 loop
    cid := public.pick_pack_card(uid);
    insert into public.owned_cards(user_id, card_id, source)
      values(uid, cid, 'pack') returning id into owned_id;
    select c.id, c.name, c.rarity, c.image_url
      into card_id, name, rarity, image_url
      from public.cards c where c.id = cid;
    return next;
  end loop;
end;
$$;

-- Keep the existing authenticated-player permission on this RPC.
grant execute on function public.open_weekly_pack() to authenticated;
