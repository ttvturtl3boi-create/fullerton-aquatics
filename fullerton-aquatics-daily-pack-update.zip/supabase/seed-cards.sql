-- Starter catalog for the current Fullerton Aquatics card images.
-- Run after schema.sql. The image paths are served from this Next.js site's /public/cards folder.
insert into public.cards(name,rarity,image_url,active) values
('Toby Swanson','Basic','/cards/Toby Swanson Fullerton Aquatics Card.png',true),
('Rocco Alverino','Basic','/cards/Rocco Alverino Fullerton Aquatics Card.png',true),
('Karl Loose','Basic','/cards/Fullerton Aquatics Karl Loose Card.png',true),
('Samuel Laven','Basic','/cards/Samuel Laven Fullerton Aquatics Card.png',true),
('Andre Johnson','Basic','/cards/Andre Johnson Fullerton Aquatics Card.png',true),
('Ari Klatzker','Basic','/cards/Ari Klatzker Fullerton Aquatics Card.png',true),
('Anthony Jacobs','Basic','/cards/Fullerton Aquatics: Anthony Jacobs Card.png',true),
('Mythical Card','Mythical','/cards/Mythic Fullerton Aquatics Card(1).png',true),
('Holographic Mythical','Mythical','/cards/Holographic Fullerton Aquatics Mythic Card.png',true),
('Coach Bock','Ultra Bazinga','/cards/Ultra Bazinga Coach Bock Card.png',true),
('K-Dawg','Ultra Bazinga','/cards/Ultra Bazinga K-Dawg Card.png',true);
