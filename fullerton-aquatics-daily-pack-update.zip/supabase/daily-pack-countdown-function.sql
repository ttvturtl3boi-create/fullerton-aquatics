-- FULLERTON AQUATICS TCG
-- Add the server-authoritative midnight Pacific reset timestamp.
-- Run this AFTER the daily-pack migration that created pack_date
-- and public.open_daily_pack().

create or replace function public.next_daily_pack_reset()
returns timestamptz
language sql
stable
as $$
    select (
        (
            (now() at time zone 'America/Los_Angeles')::date + 1
        )::timestamp
        at time zone 'America/Los_Angeles'
    );
$$;

revoke all on function public.next_daily_pack_reset() from public;
grant execute on function public.next_daily_pack_reset() to authenticated;
