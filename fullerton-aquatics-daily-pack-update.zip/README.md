# Fullerton Aquatics update

This package combines the 48-hour pack cooldown/countdown and clearer signup feedback.

## Apply the update
1. Run `supabase/48-hour-pack-cooldown.sql` in the existing Supabase SQL Editor. Do not run `seed-cards.sql`.
2. Upload this ZIP to Vercel as the new project source and deploy. Keep the existing project and its environment variables.
3. Test signup with one teammate before sharing the link widely.

The signup UI now displays Supabase errors and confirmation instructions. It does not disable email confirmation or automatically approve accounts.

The website still needs testing before public team-wide use.
